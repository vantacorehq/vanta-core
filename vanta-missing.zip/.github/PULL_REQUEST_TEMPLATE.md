## Change

## Checklist
- [ ] `make test` passes
- [ ] No new dependencies
- [ ] Monochrome palette only
