---
name: Bug report
about: Something broke
labels: bug
---
**What happened**

**Expected**

**Environment** (OS, browser / GPU, Python version)
