"""Three more stdlib-only looping GIFs: tunnel, glitch title, equalizer."""
import math, os, random
import make_motion as mm
from make_social_preview import F

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets")

def size(w, h): mm.W, mm.H = w, h

def tunnel(n=30, w=480, h=270):
    size(w, h); fr_list = []
    for f in range(n):
        t = f / n; fr = bytearray(w * h)
        for y in range(h):                                   # vignette
            for x in range(w): fr[y * w + x] = max(0, 12 - int(10 * math.hypot((x - w / 2) / w * 2, (y - h / 2) / h * 2)))
        for k in range(-1, 10):
            s = 2 ** (k + t); hw, hh = int(10 * s * 1.78), int(10 * s)
            v = int(min(255, 40 + 215 * (1 - 1 / (1 + s / 3))) * max(0, 1 - s / 90)) if s > .6 else 0
            x0, y0 = w // 2 - hw, h // 2 - hh
            mm.rect(fr, x0, y0, 2 * hw, 2, v); mm.rect(fr, x0, y0 + 2 * hh, 2 * hw, 2, v)
            mm.rect(fr, x0, y0, 2, 2 * hh, v); mm.rect(fr, x0 + 2 * hw, y0, 2, 2 * hh + 2, v)
        for i in range(0, 360, 30):                          # radial rails
            a = math.radians(i + 8 * t)
            for r in range(8, 400, 3):
                mm.put(fr, int(w / 2 + r * math.cos(a)), int(h / 2 + r * .56 * math.sin(a)), max(0, 40 - r // 10))
        fr_list.append(fr)
    mm.gif(os.path.join(OUT, "vanta-tunnel.gif"), fr_list, 4)

def glitch(n=24, w=640, h=200):
    size(w, h); random.seed(9); fr_list = []; cell, x0, y0 = 10, 35, 75
    def text(buf, dx, v):
        cx = 0
        for ch in "VANTA CORE":
            if ch == " ": cx += 3; continue
            for r, row in enumerate(F[ch]):
                for c, p in enumerate(row):
                    if p == "#": mm.rect(buf, x0 + dx + (cx + c) * cell, y0 + r * cell, cell - 1, cell - 1, v)
            cx += 6
    for f in range(n):
        buf = bytearray(w * h)
        for y in range(0, h, 4): mm.rect(buf, 0, y, w, 1, 10)            # scanlines
        strong = f % 8 in (3, 4); text(buf, 7 if strong else 3, 70); text(buf, 0, 245)
        out = bytearray(buf); y = 0
        while y < h:
            bh = random.randint(3, 14)
            if random.random() < (.45 if strong else .04):
                dx = random.randint(-40, 40) if strong else random.randint(-6, 6)
                for yy in range(y, min(h, y + bh)):
                    row = buf[yy * w:(yy + 1) * w]; out[yy * w:(yy + 1) * w] = row[-dx:] + row[:-dx] if dx else row
            y += bh
        for _ in range(30 if strong else 4): mm.rect(out, random.randint(0, w - 60), random.randint(0, h - 2), random.randint(10, 60), 2, random.choice((90, 160, 230)))
        fr_list.append(out)
    mm.gif(os.path.join(OUT, "vanta-glitch.gif"), fr_list, 5)

def equalizer(n=32, w=640, h=200):
    size(w, h); random.seed(4); bars = 48; ph = [(random.random(), random.randint(1, 3)) for _ in range(bars)]; fr_list = []
    for f in range(n):
        t = f / n; fr = bytearray(w * h)
        for y in range(0, h, 20): mm.rect(fr, 0, y, w, 1, 16)
        for i, (p, k) in enumerate(ph):
            e = .5 + .5 * math.sin(2 * math.pi * (k * t + p)); e2 = .5 + .5 * math.sin(2 * math.pi * (t + i / bars))
            hh = int(12 + 150 * e * (.4 + .6 * e2)); x = 8 + i * 13
            for s in range(0, hh, 6): mm.rect(fr, x, h - 12 - s - 4, 10, 4, 40 + int(190 * s / 160))
            mm.rect(fr, x, h - 12 - hh - 8, 10, 3, 255)
        fr_list.append(fr)
    mm.gif(os.path.join(OUT, "vanta-equalizer.gif"), fr_list, 4)

if __name__ == "__main__":
    tunnel(); glitch(); equalizer()
