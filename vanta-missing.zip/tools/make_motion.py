"""Pure-stdlib animated GIF: black-hole accretion loop -> assets/vanta-motion.gif (seamless loop)."""
import math, os, random, struct
from make_social_preview import F

W, H, N = 640, 360, 36
CX, CY = W // 2, H // 2

def lzw(data: bytes) -> bytes:
    clear, eoi = 256, 257
    out, buf, nb, size, nxt, table = bytearray(), 0, 0, 9, 258, {}
    def emit(c):
        nonlocal buf, nb
        buf |= c << nb; nb += size
        while nb >= 8: out.append(buf & 255); buf >>= 8; nb -= 8
    emit(clear); prefix = data[0]
    for b in data[1:]:
        k = (prefix << 8) | b
        if k in table: prefix = table[k]; continue
        emit(prefix)
        if nxt < 4096:
            table[k] = nxt
            if nxt == (1 << size) and size < 12: size += 1
            nxt += 1
        else:
            emit(clear); table.clear(); size, nxt = 9, 258
        prefix = b
    emit(prefix); emit(eoi)
    if nb: out.append(buf & 255)
    return bytes(out)

def gif(path, frames, delay=4):
    pal = b"".join(bytes((i, i, i)) for i in range(256))
    o = bytearray(b"GIF89a" + struct.pack("<HHBBB", W, H, 0xF7, 0, 0) + pal)
    o += b"\x21\xFF\x0BNETSCAPE2.0\x03\x01\x00\x00\x00"
    for fr in frames:
        o += b"\x21\xF9\x04\x00" + struct.pack("<H", delay) + b"\x00\x00"
        o += b"\x2C" + struct.pack("<HHHHB", 0, 0, W, H, 0) + b"\x08"
        d = lzw(bytes(fr))
        for i in range(0, len(d), 255): o += bytes([min(255, len(d) - i)]) + d[i:i + 255]
        o += b"\x00"
    open(path, "wb").write(o + b"\x3B")

def put(fr, x, y, v, s=1):
    for j in range(s):
        for i in range(s):
            xx, yy = x + i, y + j
            if 0 <= xx < W and 0 <= yy < H and fr[yy * W + xx] < v: fr[yy * W + xx] = v

def rect(fr, x, y, w, h, v):
    for j in range(y, y + h):
        for i in range(x, x + w):
            if 0 <= i < W and 0 <= j < H and fr[j * W + i] < v: fr[j * W + i] = v

def render(f, parts, base):
    t = f / N; fr = bytearray(base)
    off = int(t * 40)
    for x in range(-off % 40, W, 40): rect(fr, x, 0, 1, H, 20)          # drifting grid
    for y in range(0, H, 40): rect(fr, 0, y, W, 1, 20)
    for k, (x, y, w, h) in enumerate([(30, 30, 150, 80), (470, 24, 140, 60), (440, 270, 170, 60), (28, 262, 110, 64)]):
        dx = int(10 * math.sin(2 * math.pi * (t + k / 4)))
        rect(fr, x + dx, y, w, 2, 90); rect(fr, x + dx, y + h, w, 2, 90); rect(fr, x + dx, y, 2, h, 90); rect(fr, x + dx + w, y, 2, h + 2, 90)
    for a0, r0, p0, k, s, v in parts:                                    # spiralling particles
        ph = (p0 + t) % 1.0; r = r0 * (1 - ph) ** 1.6 + 10
        a = a0 + 2 * math.pi * k * t + (1 - ph) * 4.0
        v2 = int(v * math.sin(math.pi * ph) ** .6)
        x, y = int(CX + r * math.cos(a)), int(CY + r * .55 * math.sin(a))
        put(fr, x, y, v2, s)
        if ph > .6 and r > 14: put(fr, int(CX + (r + 5) * math.cos(a - .12)), int(CY + (r + 5) * .55 * math.sin(a - .12)), v2 // 2, 1)
    for R, v in ((26, 230), (30, 130), (36, 60)):                       # accretion rings
        for i in range(360):
            a = i * math.pi / 180; pulse = .5 + .5 * math.sin(2 * math.pi * (t * 2 + i / 360))
            put(fr, int(CX + R * math.cos(a)), int(CY + R * .55 * math.sin(a)), int(v * (.45 + .55 * pulse)))
    for y in range(CY - 14, CY + 15):                                   # event horizon
        for x in range(CX - 24, CX + 25):
            if ((x - CX) / 24) ** 2 + ((y - CY) / 14) ** 2 < 1: fr[y * W + x] = 0
    sy = int(t * H)                                                     # scanline
    rect(fr, 0, sy, W, 2, 70)
    cell, x0, cx = 6, 24, 0
    for ch in "VANTA CORE":                                             # tiny pixel title
        if ch == " ": cx += 3; continue
        for r, row in enumerate(F[ch]):
            for c, v in enumerate(row):
                if v == "#": rect(fr, x0 + (cx + c) * cell // 2 * 1, 322 + r * 3, 3, 3, 210)
        cx += 6
    return fr

if __name__ == "__main__":
    random.seed(5)
    base = bytearray(W * H)
    for y in range(H):
        for x in range(W):
            d = math.hypot((x - CX) / W * 2, (y - CY) / H * 2)
            base[y * W + x] = max(0, 14 - int(10 * d) + random.randint(0, 3))
    parts = [(random.random() * 6.283, random.uniform(60, 300), random.random(), random.choice((1, 2, 3)),
              random.choice((1, 1, 2, 2, 3)), random.choice((90, 140, 200, 255))) for _ in range(380)]
    out = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "vanta-motion.gif")
    gif(out, [render(f, parts, base) for f in range(N)])
    print(out, os.path.getsize(out))
