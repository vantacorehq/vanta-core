"""Pure-stdlib PNG renderer: assets/social-preview.png (1280x640) and assets/texture-carbon.png (512x512)."""
import os, random, struct, zlib
F = {"V":["#...#","#...#","#...#",".#.#.","..#.."],"A":[".###.","#...#","#####","#...#","#...#"],
     "N":["#...#","##..#","#.#.#","#..##","#...#"],"T":["#####","..#..","..#..","..#..","..#.."],
     "C":[".####","#....","#....","#....",".####"],"O":[".###.","#...#","#...#","#...#",".###."],
     "R":["####.","#...#","####.","#..#.","#...#"],"E":["#####","#....","####.","#....","#####"]}
def png(path, w, h, px):
    raw = b"".join(b"\0" + bytes(px[y * w:(y + 1) * w]) for y in range(h))
    ck = lambda t, d: struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d))
    open(path, "wb").write(b"\x89PNG\r\n\x1a\n" + ck(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 0, 0, 0, 0))
                           + ck(b"IDAT", zlib.compress(raw, 9)) + ck(b"IEND", b""))
def rect(px, W, H, x, y, w, h, v):
    for j in range(max(0, y), min(H, y + h)):
        for i in range(max(0, x), min(W, x + w)): px[j * W + i] = v
def social(path):
    W, H = 1280, 640; random.seed(3); px = bytearray(W * H)
    for y in range(H):
        for x in range(W):
            d = ((x - 640) ** 2 + (y - 320) ** 2) ** .5 / 800
            v = 10 - int(6 * d) + random.randint(0, 4)
            if x % 40 == 0 or y % 40 == 0: v += 8
            px[y * W + x] = max(0, v)
    for x, y, w, h, v in [(70,60,300,170,22),(930,50,290,130,18),(860,440,320,120,16),(80,470,240,110,20)]:
        rect(px, W, H, x, y, w, h, v)
        for e in (rect,): e(px, W, H, x, y, w, 3, 90); e(px, W, H, x, y + h - 3, w, 3, 90); e(px, W, H, x, y, 3, h, 90); e(px, W, H, x + w - 3, y, 3, h, 90)
    for _ in range(9000):  # particle swarm drawn toward centre
        a = random.random() * 6.283; r = (random.random() ** 2.2) * 620
        x = int(640 + r * __import__("math").cos(a)); y = int(320 + r * .6 * __import__("math").sin(a))
        rect(px, W, H, x, y, random.choice((1, 1, 2, 3)), random.choice((1, 2)), random.choice((70, 110, 150, 200)))
    cell = 18; x0 = (W - (9 * 6 + 4) * cell + cell) // 2; y0 = 215; cx = 0
    for ch in "VANTA CORE":
        if ch == " ": cx += 4; continue
        for r, row in enumerate(F[ch]):
            for c, v in enumerate(row):
                if v == "#":
                    X, Y = x0 + (cx + c) * cell, y0 + r * cell
                    rect(px, W, H, X + 8, Y + 8, cell - 1, cell - 1, 60); rect(px, W, H, X, Y, cell - 1, cell - 1, 245)
        cx += 6
    for i in range(0, W, 6): rect(px, W, H, i, 560, 3, 6, 120)
    png(path, W, H, px)
def texture(path):
    random.seed(11); W = H = 512; px = bytearray(W * H)
    for y in range(H):
        for x in range(W):
            v = 14 + random.randint(0, 10) + (6 if (x // 2 + y // 2) % 2 else 0) + (10 if (x + y) % 64 < 2 else 0)
            px[y * W + x] = v
    png(path, W, H, px)
if __name__ == "__main__":
    d = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets")
    os.makedirs(d, exist_ok=True); social(os.path.join(d, "social-preview.png")); texture(os.path.join(d, "texture-carbon.png"))
