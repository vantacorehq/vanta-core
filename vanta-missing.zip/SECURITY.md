# Security
The metrics endpoint binds to 127.0.0.1 only. Do not expose it publicly.
Report vulnerabilities privately through GitHub Security Advisories (Security tab), not public issues.
