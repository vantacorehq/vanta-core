# Code of Conduct
Be direct, be respectful. No harassment, discrimination or personal attacks. Maintainers may remove content and ban contributors who violate this. Report issues via a private maintainer contact listed on the profile.
