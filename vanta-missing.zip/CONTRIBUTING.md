# Contributing
- Zero dependencies: stdlib Python 3.11+ and vanilla WebGL 2.0 only.
- Palette stays black / charcoal / carbon grey. No colour.
- Run `make test` before opening a PR.
- Keep the policy engine fail-closed: on any doubt, reject the chunk.
