# Architecture
```
Simulator (os.urandom bursts) -> analyse() -> RenderPolicy.ingest -> Metrics
                                                   |  fail-closed reject
Metrics -> MetricsProtocol (HTTP /metrics, 127.0.0.1:8765) -> index.html
Metrics -> vanta_terminal.py (in-process) -> ANSI frame
```
- **Spike** = (throughput - slow baseline) / baseline, clamped 0..1. It drives the terminal collapse and the WebGL pulse.
- **Policy** rejects wrong size, bad hex round-trip, NaN, out-of-range values; survivors are sorted by density in batches of 32.
- **WebGL**: no vertex buffers; positions are hashed from `gl_VertexID` in the vertex shader.
