# Changelog
## 1.0.0
- Async stream simulator, fail-closed render policy, ANSI black-hole terminal, 2M-particle WebGL2 engine.
- Animated banner, social preview, logo, CI, tests, local server.
- Looping black-hole motion GIF + mp4.
- Motion pack: glitch, equalizer, tunnel GIFs.
